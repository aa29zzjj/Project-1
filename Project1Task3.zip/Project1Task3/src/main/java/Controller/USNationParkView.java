package Controller;

import java.util.List;
//to check the value of the model variables
public class USNationParkView {

    public void displayImageURL(String imageURL) {
        System.out.println("Park Image URL: " + imageURL);
    }

    public void displayWeatherDetails(String weatherDetails) {
        System.out.println("Weather Condition: ");
        System.out.println(weatherDetails);
    }

    public void displayActivities(List<String> activities) {
        System.out.println("Available Activities:");
        for (String activity : activities) {
            System.out.println("- " + activity);
        }
    }
}


