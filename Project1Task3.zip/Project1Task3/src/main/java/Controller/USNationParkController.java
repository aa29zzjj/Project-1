package Controller;
import model.USNationParkModel;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.List;


//Controllers for handling the model for the task 3 data: parkName, imgURL, weather condition, and activities
public class USNationParkController {
    private USNationParkModel model;
    //view: for sending out the print to check the value of variables
    private USNationParkView view;
    //Constructor
    public USNationParkController(USNationParkModel model, USNationParkView view) {
        this.model = model;
        this.view = view;
    }

    // Fetch and print out imgURL
    public void showParkImage(String parkCode) {
        String imageUrl = model.fetchParkImage(parkCode);
        model.setImageURL(imageUrl);
        view.displayImageURL(model.getImageURL());
    }

    // Fetch and print out the String of weatherCondition
    public void showParkWeatherCond(double latitude, double longitude) {
        String weatherCondition = model.fetchParkWeather(latitude, longitude);
        model.setWeatherCondition(weatherCondition);
        view.displayWeatherDetails(model.getWeatherCondition());
    }

    // Fetch and print out activitiesList
    public void showParkActivitiesList(String apiKey, String parkCode) throws NoSuchAlgorithmException, KeyManagementException {
        List<String> activities = model.fetchParkActivities(apiKey, parkCode);
        model.setActivitiesList(activities);
        view.displayActivities(model.getActivitiesList());
    }
    //setters & getters
    public void setModelParkName(String parkName) {
        model.setParkName(parkName);
    }

    public String getModelParkName(){
        return model.getParkName();
    }
    public String getModelImgURL(){
        return model.getImageURL();
    }
    public String getModelWeatherCondition(){
        return model.getWeatherCondition();
    }
    public List<String> getModelActivitiesList(){
        return model.getActivitiesList();
    }
}


