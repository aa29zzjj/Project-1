package model;
import com.google.gson.Gson;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;


import javax.net.ssl.*;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.ArrayList;


public class USNationParkModel {
    private String parkName;
    private String imageURL;
    private String weatherCondition;
    private List<String> activities_list;
//Constructor
    public USNationParkModel() {
        this.parkName = "";
        this.imageURL = "";
        this.weatherCondition = "";
        this.activities_list = new ArrayList<>();
    }
    public USNationParkModel(String parkName, String imageURL, String weatherCondition, List<String> activities_list) {
        this.parkName = parkName;
        this.imageURL = imageURL;
        this.weatherCondition = weatherCondition;
        this.activities_list = activities_list;
    }
//getter & setters
    public String getParkName() {
        return parkName;
    }

    public void setParkName(String parkName) {
        this.parkName = parkName;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getWeatherCondition() {
        return weatherCondition;
    }

    public void setWeatherCondition(String weatherCondition) {
        this.weatherCondition = weatherCondition;
    }

    public List<String> getActivitiesList() {
        return activities_list;
    }

    public void setActivitiesList(List<String> activities) {
        this.activities_list = activities;
    }

    // Fetch the screen scarping image
    public String fetchParkImage(String parkCode) {
        String searchImgURL = "https://www.nps.gov/" + parkCode + "/index.htm";
        try {
            //SSLHandshakeException
            createTrustManager("TLSV1.3");

            // Connect to the park's page on www.nps.gov
            Document doc = Jsoup.connect(searchImgURL).timeout(5000).get();

            // By checking the html code from website, select the div id='HeroBanner' image
            Element heroBannerDiv = doc.select("div#HeroBanner.HeroBanner").first();

            // If the div is found, extract the background image URL
            if (heroBannerDiv != null) {
                // Find the div with the class "picturefill-background"
                Element backgroundDiv_element = heroBannerDiv.select("div.picturefill-background").first();
                // if the element has value then fetch the image
                if (backgroundDiv_element != null) {
                    // Extract the background image URL from the style attribute
                    String style = backgroundDiv_element.attr("style");

                    // Use regex to fetch the URL inside the background-image
                    String imageURL = style.replaceAll(".*url\\(['\"]?(.*?)['\"]?\\).*", "$1");

                    // Return image URL
                    return "https://www.nps.gov" + imageURL;
                }
            }
            return "Image not found";
        } catch (IOException e) {
            e.printStackTrace();
            return "Fetching image failed";
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        } catch (KeyManagementException e) {
            throw new RuntimeException(e);
        }
    }


    // To Fetch park weather using latitude and longitude
    public String fetchParkWeather(double latitude, double longitude) {
        //API URL
        String api_URL = "https://forecast.weather.gov/MapClick.php?lat=" + latitude + "&lon=" + longitude;

        try {
            //SSLHandshakeException
            createTrustManager("TLSV1.3");
            // Using Jsoup to fetch the webpage
            Document doc = Jsoup.connect(api_URL).timeout(5000).get();

            // Extract the temperature value from the webpage
            Element temperature_element = doc.selectFirst("p.myforecast-current-lrg");
            // Extract the humidity value from the webpage
            Element humidity_element = doc.selectFirst("td:contains(Humidity) + td");
            // Extract the wind speed value from the webpage
            Element windSpeed_element = doc.selectFirst("td:contains(Wind) + td");

            //make it into text
            String temperature = temperature_element.text();
            String humidity = humidity_element.text();
            String windSpeed = windSpeed_element.text();
            // Return to String
            return String.format("Temperature: %s<br>Humidity: %s<br>Wind Speed: %s", temperature, humidity, windSpeed);

        } catch (IOException e) {
            e.printStackTrace();
            return "Data Loading failed";
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        } catch (KeyManagementException e) {
            throw new RuntimeException(e);
        }
    }

    // To fetch activities for the park from NPS API
    public List<String> fetchParkActivities(String api_key, String parkCode) throws NoSuchAlgorithmException, KeyManagementException {

        // Use API to fetch the activities
        String api_URL = "https://developer.nps.gov/api/v1/activities?parkCode=" + parkCode + "&api_key=" + api_key;

        // list for activities
        List<String> listOfActivities = new ArrayList<>();

        try {
            //SSLHandshakeException
            createTrustManager("TLSV1.3");
            // Fetch the data from the API
            String json = Jsoup.connect(api_URL).ignoreContentType(true).execute().body();

            // Use Gson to parse Json data
            Gson gson = new Gson();
            ActivitiesList activitiesResponse = gson.fromJson(json, ActivitiesList.class);
            // Add the activities into activity list
            for (Activity activity : activitiesResponse.getData()) {
                listOfActivities.add(activity.getName());
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        // Return the list of activities
        return listOfActivities;
    }

    private void createTrustManager(String certType) throws KeyManagementException, NoSuchAlgorithmException {
        /**
         * Annoying SSLHandShakeException. After trying several methods, finally this
         * seemed to work.
         * Taken from: http://www.nakov.com/blog/2009/07/16/disable-certificate-validation-in-java-ssl-connections/
         */
        // Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }
            public void checkClientTrusted(X509Certificate[] certs, String authType) {
            }
            public void checkServerTrusted(X509Certificate[] certs, String authType) {
            }
        }
        };

        // Install the all-trusting trust manager
        SSLContext sc = SSLContext.getInstance(certType);
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

        // Create all-trusting host name verifier
        HostnameVerifier allHostsValid = new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };

        // Install the all-trusting host verifier
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
    }

}
