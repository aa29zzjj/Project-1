package model;

//used to receive the activities
class Activity {
    private String name;

    public String getName() {
        return name;
    }
}