package model;
import java.util.List;
public class ParkDataList {
        private List<ParkData> listOfParks;

        public List<ParkData> getParks() {
            return listOfParks;
        }

        public void setParks(List<ParkData> parks) {
            this.listOfParks = parks;
        }


}
