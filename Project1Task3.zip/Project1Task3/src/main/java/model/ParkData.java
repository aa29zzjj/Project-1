package model;

//to extract the data from ParksData.json (figure 9)
public class ParkData {
    private String parkName;
    private String parkFullName;
    private String parkCode;
    private double latitude;
    private double longitude;
//Constructors
    public ParkData() {
        this.parkName = "";
        this.parkFullName = "";
        this.parkCode = "";
        this.latitude = 0.0;
        this.longitude = 0.0;

    }
    public ParkData(String parkName, String parkFullName, String parkCode, Double latitude, Double longitude) {
        this.parkName = parkName;
        this.parkFullName = parkFullName;
        this.parkCode = parkCode;
        this.latitude = latitude;
        this.longitude = longitude;
    }
//getters
    public String getParkName() {
        return parkName;
    }

    public String getParkFullName() {
        return parkFullName;
    }

    public String getParkCode() {
        return parkCode;
    }

    public Double getLatitude() {
        return latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

}
