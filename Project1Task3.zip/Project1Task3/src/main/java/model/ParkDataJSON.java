package model;
import com.google.gson.Gson;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

//Used to read JSON file
public class ParkDataJSON {

    private static final String JSON_FILE_PATH = "C:\\Users\\USER\\IdeaProjects\\Project1Task3\\ParksData.json";

    public static List<ParkData> fetchParkDataFromJson() throws IOException {
        Gson gson = new Gson();
        FileReader reader = new FileReader(JSON_FILE_PATH);
        // Deserialize the JSON data into a list of Park objects
        ParkDataList parksDataList = gson.fromJson(reader, ParkDataList.class);
        return parksDataList.getParks();
    }
}

