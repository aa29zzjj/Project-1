package model;
import java.util.List;

//used to receive the activities
class ActivitiesList {
    private List<Activity> data;

    public List<Activity> getData() {
        return data;
    }
}
