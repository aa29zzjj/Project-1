package ds.project1task3;
import Controller.USNationParkController;
import Controller.USNationParkView;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.ParkData;
import model.ParkDataJSON;
import model.USNationParkModel;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

@WebServlet("/result")
public class USNationParkServlet extends HttpServlet {

     USNationParkModel parkModel = null;
     USNationParkView parkView = null;
     USNationParkController controller = null;
    // Initiate this servlet by instantiating the model that it will use.
    @Override
    public void init() {
        parkModel = new USNationParkModel();
        parkView = new USNationParkView();
        controller = new USNationParkController(parkModel, parkView);
    }
    //to Receive the screen scraping, park info (temperature, humidity, wind speed), and Activities
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String parkName = request.getParameter("park");
        //API key
        String ApiKey = "5A0FeqBXwbswl435MQcTg5CKgnEIl659SysLgYkd";
        //read ParksData.json I draft
        List<ParkData> parks = ParkDataJSON.fetchParkDataFromJson();
        ParkData selectedPark = null;

        // Find the park by name
        for (ParkData park : parks) {
            if (park.getParkName().equalsIgnoreCase(parkName)) {
                selectedPark = park;
                break;
            }
        }
        //Use controller to handle the value
        // Make the parkName become full name
        controller.setModelParkName(selectedPark.getParkFullName());
        String parkFullName = controller.getModelParkName();
        //take off the NP from the park selection:
        String park_name_without_NP = controller.getModelParkName().substring(0, selectedPark.getParkName().length() - 2);
        // Fetch park image by parkCode
        controller.showParkImage(selectedPark.getParkCode());
        String parkImage = controller.getModelImgURL();
        // Fetch park info by park's latitude and longitude
        controller.showParkWeatherCond(selectedPark.getLatitude(), selectedPark.getLongitude());
        String weatherData = controller.getModelWeatherCondition();
        // Fetch activities by park code and ApiKey
        try {
            controller.showParkActivitiesList(ApiKey, selectedPark.getParkCode());
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        } catch (KeyManagementException e) {
            throw new RuntimeException(e);
        }
        List<String> activities = controller.getModelActivitiesList();

        // Set attributes to pass to result.jsp
        request.setAttribute("parkFullName", parkFullName);
        request.setAttribute("parkImage", parkImage);
        request.setAttribute("imageCredit", "www.nps.gov");
        request.setAttribute("weather", weatherData);
        request.setAttribute("weatherCredit", "forecast.weather.gov");
        request.setAttribute("parkName", park_name_without_NP);
        request.setAttribute("activities", activities);
        request.setAttribute("activitiesCredit", "https://developer.nps.gov");

        // Forward to result.jsp
        RequestDispatcher dispatcher = request.getRequestDispatcher("result.jsp");
        dispatcher.forward(request, response);
    }
}
