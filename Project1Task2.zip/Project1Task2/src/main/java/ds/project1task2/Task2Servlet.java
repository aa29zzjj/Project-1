package ds.project1task2;
import jakarta.servlet.ServletException;
import java.io.IOException;
import java.util.Map;

import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.Task2Model;


@WebServlet( urlPatterns = {"/submit", "/getResults"})
public class Task2Servlet  extends HttpServlet{
    Task2Model responses = null;

    // Initiate this servlet by instantiating the model that it will use.
    @Override
    public void init() {

        responses = new Task2Model();
    }
    //to post the submission of clicker
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String answer = request.getParameter("answer");

        if (answer != null) {
            //set into reponses model
            responses.addResponse(answer);
            //show out feedback shows the registered answer
            request.setAttribute("feedback", "Your answer ' " + answer + " ' has been registered.");
        }
        //send out the request
        request.getRequestDispatcher("/index.jsp").forward(request, response);

    }
    //to get the clicker result Map
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = request.getServletPath();
        //for returning to /index.jsp page
        if ("/submit".equals(path)) {
            // Redirect to index.jsp (front page)
            response.sendRedirect("index.jsp");
            return;
        }
        //check whether user had clicked the ABCD and submit or not
        if ("/getResults".equals(path)) {
            Map<String, Integer> answer_result_responses = responses.getResponses();
            boolean isClicked = false;
            for (Integer count : answer_result_responses.values()) {
                if (count > 0) {
                    isClicked = true;
                    break;
                }
            }
            if (isClicked) {
                //if the result is clicked, set up the records of resultMap
                request.setAttribute("resultsMap", answer_result_responses);
            }
            // Clear results after display
            responses.clearResponses();
            //send out the request to /result.jsp
            request.getRequestDispatcher("/result.jsp").forward(request, response);
        }
    }
}
