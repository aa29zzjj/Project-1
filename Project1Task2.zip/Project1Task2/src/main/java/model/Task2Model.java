package model;
import java.util.HashMap;
import java.util.Map;


public class Task2Model {
    //use HashMap to record the submissions
    private Map<String, Integer> responses = new HashMap<>();

    public Task2Model() {
        // Initialize with all choices set to 0
        responses = new HashMap<>();
        responses.put("A", 0);
        responses.put("B", 0);
        responses.put("C", 0);
        responses.put("D", 0);
    }
    //Once submit, add the submission into model
    public void addResponse(String answer) {
        if (responses.containsKey(answer)) {
            responses.put(answer, responses.get(answer) + 1);
        }
    }
    //getter
    public Map<String, Integer> getResponses() {
        return new HashMap<>(responses); // Return sorted results
    }
    //to clear the Model once return back to index.jsp
    public void clearResponses() {
        responses.put("A", 0);
        responses.put("B", 0);
        responses.put("C", 0);
        responses.put("D", 0);
    }

}
