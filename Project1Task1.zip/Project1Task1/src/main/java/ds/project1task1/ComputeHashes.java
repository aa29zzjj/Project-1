package ds.project1task1;
import java.io.PrintWriter;
import jakarta.xml.bind.DatatypeConverter;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
//import the packages required in Task 1
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@WebServlet("/ComputeHashes")
public class ComputeHashes extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Received the text from user
        String text = request.getParameter("text");
        //Received the type of compute from users
        String hashComputeRequest = request.getParameter("hashComputeRequest");

        String compute_in_hex = "";
        String compute_in_base64 = "";

        try {
            //Use MessageDigest.getInstance to digest the compute request
            MessageDigest digest_request = MessageDigest.getInstance(hashComputeRequest);
            byte[] request_in_byte =  digest_request.digest(text.getBytes());
            //Compute the input text and compute
            //Code snippets of computation of each hash
            compute_in_hex = DatatypeConverter.printHexBinary(request_in_byte);
            compute_in_base64 = DatatypeConverter.printBase64Binary(request_in_byte);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        // Show out the details on website
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><body>");
        out.println("<h1>Generation Results for Hash Computation</h1>");
        out.println("<p>Typed Text: " + text + "</p>");
        out.println("<p>Hash Compute Request Name: " + hashComputeRequest + "</p>");
        out.println("<p>Hexadecimal Hash: " + compute_in_hex + "</p>");
        out.println("<p>Base64 Hash: " + compute_in_base64 + "</p>");
        out.println("</body></html>");
    }

}
